Execution : Program.exe in windows.
		