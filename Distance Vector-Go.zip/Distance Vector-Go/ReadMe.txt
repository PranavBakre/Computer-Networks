For Execution:

Windows : main.exe

Linux: ./main

Other instructions in main.go file
